# Clustering using Particle Swarm Optimization

## Reference

1. [Data clustering using particle swarm optimization](https://ieeexplore.ieee.org/document/1299577)

## Usage

Check on [notebook](./Untitled.ipynb)